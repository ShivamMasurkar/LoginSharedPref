package eu.tutorials.myapplication

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_main2.*


import android.content.Intent
import android.content.SharedPreferences


class MainActivity2 : AppCompatActivity() {


    lateinit var preferences: SharedPreferences
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)


        preferences=getSharedPreferences("Shared_pref", MODE_PRIVATE)
        val email=preferences.getString("email","")
        nametv.text=email
        val password=preferences.getString("password","")
        agetv.text=password

        logout.setOnClickListener{
            val editor:SharedPreferences.Editor=preferences.edit()
            editor.clear()
            editor.apply()

            val intent= Intent(this,MainActivity::class.java)
            startActivity(intent)
            finish()
        }




        }




    }
