package eu.tutorials.myapplication



import android.content.Intent
import android.content.SharedPreferences
import android.content.SharedPreferences.Editor
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

import kotlinx.android.synthetic.main.activity_main.*


class MainActivity : AppCompatActivity() {


    lateinit var sharedPreferences:SharedPreferences
    var isRemembered=false
    // get reference to button
    private  lateinit var  builder:AlertDialog.Builder


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        emailEt.addTextChangedListener(object:TextWatcher {
            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {

            }

            override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
                if(  android.util.Patterns.EMAIL_ADDRESS.matcher(emailEt.text.toString()).matches())
                    login.isEnabled=true
                else{
                    login.isEnabled=false
                    emailEt.setError("Invalid Email")
                }

            }

            override fun afterTextChanged(p0: Editable?) {

            }
        })


        sharedPreferences = getSharedPreferences("Shared_pref", MODE_PRIVATE)
        isRemembered=sharedPreferences.getBoolean("Checkbox",false)
        if(isRemembered){

            //  val intent=Intent(this,AnotherActivity::class.java)
            //startActivity(intent)
            //finish()

            val email=sharedPreferences.getString("email","")
            emailEt.setText(email)
            val password = sharedPreferences.getString("password","")
            passwordEt.setText(password)



        }


        login.setOnClickListener{

            val email :String=emailEt.text.toString()
            val password :String=passwordEt.text.toString()
            val checked:Boolean=checkBox.isChecked



            if (password == "") {
                builder=AlertDialog.Builder(this)
                builder.setTitle("Alert")
                    .setMessage("insert password")
                    .setPositiveButton(
                        "OK"
                    ) { dialogInterface, i -> dialogInterface.cancel() }
                    .show()
            } else {


                val editor: Editor = sharedPreferences.edit()
                editor.putString("email", email)
                editor.putString("password", password)
                editor.putBoolean("Checkbox", checked)
                editor.apply()

                Toast.makeText(this, "Information has been saved", Toast.LENGTH_LONG).show()

                val intent = Intent(this, MainActivity2::class.java)
                startActivity(intent)
                finish()
            }

        }




    }
}


